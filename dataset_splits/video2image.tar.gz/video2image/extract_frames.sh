#!/bin/bash
GPUID=0
ROOTDIR=/raid/dataset

# Compile for optical flow extraction
make clean
export LD_LIBRARY_PATH=$PWD
make


# Convert training video files into images
VIDEOPATH=$ROOTDIR/IsoGD_phase_1/train
IMAGEPATH=$ROOTDIR/IsoGD_Image/train_image
mkdir -m 755 $ROOTDIR/IsoGD_Image
mkdir -m 755 $IMAGEPATH
mkdir -m 755 $IMAGEPATH/RGB
mkdir -m 755 $IMAGEPATH/Depth
mkdir -m 755 $IMAGEPATH/Flow
for dir in `ls $VIDEOPATH`
do
	VIDEOPATH=$VIDEOPATH/$dir
	for file in `ls $VIDEOPATH/M_*.avi`
	do
		FILENAME=`basename $file`
		NAME=${FILENAME%.*}
		BNAME=$IMAGEPATH/RGB/$NAME
		mkdir -m 755 $BNAME
		ffmpeg -i $file $BNAME/%06d.jpg
		FNAME=${NAME/M/F}
		BNAME=$IMAGEPATH/Flow/$FNAME
		mkdir -m 755 $BNAME
		./brox --in $file --out $BNAME --gpu $GPUID
	done
done
for dir in `ls $VIDEOPATH`
do
	VIDEOPATH=$VIDEOPATH/$dir
	for file in `ls $VIDEOPATH/K_*.avi`
	do
		FILENAME=`basename $file`
		NAME=${FILENAME%.*}
		BNAME=$IMAGEPATH/Depth/$NAME
		mkdir -m 755 $BNAME
		ffmpeg -i $file $BNAME/%06d.jpg
	done
done
# Convert validation video files into images
VIDEOPATH=$ROOTDIR/IsoGD_phase_1/valid
IMAGEPATH=$ROOTDIR/IsoGD_Image/valid_image
mkdir -m 755 $IMAGEPATH
mkdir -m 755 $IMAGEPATH/RGB
mkdir -m 755 $IMAGEPATH/Depth
mkdir -m 755 $IMAGEPATH/Flow
for dir in `ls $VIDEOPATH`
do
	VIDEOPATH=$VIDEOPATH/$dir
	for file in `ls $VIDEOPATH/M_*.avi`
	do
		FILENAME=`basename $file`
		NAME=${FILENAME%.*}
		BNAME=$IMAGEPATH/RGB/$NAME
		mkdir -m 755 $BNAME
		ffmpeg -i $file $BNAME/%06d.jpg
		FNAME=${NAME/M/F}
		BNAME=$IMAGEPATH/Flow/$FNAME
		mkdir -m 755 $BNAME
		./brox --in $file --out $BNAME --gpu $GPUID
	done
done
for dir in `ls $VIDEOPATH`
do
	VIDEOPATH=$VIDEOPATH/$dir
	for file in `ls $VIDEOPATH/K_*.avi`
	do
		FILENAME=`basename $file`
		NAME=${FILENAME%.*}
		BNAME=$IMAGEPATH/Depth/$NAME
		mkdir -m 755 $BNAME
		ffmpeg -i $file $BNAME/%06d.jpg
	done
done
# Convert testing video files into images
VIDEOPATH=$ROOTDIR/IsoGD_phase_2/test
IMAGEPATH=$ROOTDIR/IsoGD_Image/test_image
mkdir -m 755 $IMAGEPATH
mkdir -m 755 $IMAGEPATH/RGB
mkdir -m 755 $IMAGEPATH/Depth
mkdir -m 755 $IMAGEPATH/Flow
for dir in `ls $VIDEOPATH`
do
	VIDEOPATH=$VIDEOPATH/$dir
	for file in `ls $VIDEOPATH/M_*.avi`
	do
		FILENAME=`basename $file`
		NAME=${FILENAME%.*}
		BNAME=$IMAGEPATH/RGB/$NAME
		mkdir -m 755 $BNAME
		ffmpeg -i $file $BNAME/%06d.jpg
		FNAME=${NAME/M/F}
		BNAME=$IMAGEPATH/Flow/$FNAME
		mkdir -m 755 $BNAME
		./brox --in $file --out $BNAME --gpu $GPUID 
	done
done
for dir in `ls $VIDEOPATH`
do
	VIDEOPATH=$VIDEOPATH/$dir
	for file in `ls $VIDEOPATH/K_*.avi`
	do
		FILENAME=`basename $file`
		NAME=${FILENAME%.*}
		BNAME=$IMAGEPATH/Depth/$NAME
		mkdir -m 755 $BNAME
		ffmpeg -i $file $BNAME/%06d.jpg
	done
done
